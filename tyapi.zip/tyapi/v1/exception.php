<?php



set_exception_handler('myException');

class tyapiException extends Exception
{
    protected $message;
    protected $code;
    protected $errorCode;
    public function __construct($message = "", $code = 200,$errorCode=0, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
        $this->errorCode = $errorCode;
    }
    public function getErrorCode()
    {
        return $this->errorCode;
    }
}


function myException($exception)
{
    //echo "<b>Exception:</b> " , $exception->getMessage();


    https($exception->getCode());
    echo json_encode([
        "errorCode" => $exception->getErrorCode(),
        "msg" => $exception->getMessage(),

    ]);
}

set_exception_handler('myException');




