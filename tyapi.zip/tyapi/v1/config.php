<?php
const TOKEN_SALT = 'tysc201803021965';
const IMG_URL = 'http://192.168.1.194:8080/ecshop/data/afficheimg/';